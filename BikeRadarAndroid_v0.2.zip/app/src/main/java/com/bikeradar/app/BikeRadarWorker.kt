package com.bikeradar.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.max
import kotlin.math.min

data class Bike(val title: String, val url: String, val price: Int, val score: Int)

class BikeRadarWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    private val prefs = appContext.getSharedPreferences("bike_radar", Context.MODE_PRIVATE)

    override suspend fun doWork(): Result {
        val maxPrice = prefs.getInt("maxPrice", 1500)
        val minYear = prefs.getInt("minYear", 0)
        val minScore = prefs.getInt("minScore", 60)
        val token = prefs.getString("token", "") ?: ""
        val chatId = prefs.getString("chatId", "") ?: ""

        val queries = listOf(
            "mtb 29 boost",
            "e mtb",
            "trekking e bike",
            "mountainbike fully",
            "cube stereo",
            "polygon fully",
            "canyon fully",
            "trek fully",
            "specialized fully",
            "radon fully",
            "scott fully",
            "giant fully"
        )

        val found = mutableListOf<Bike>()
        for (q in queries) {
            try {
                val html = fetch("https://www.kleinanzeigen.de/s-fahrraeder/${URLEncoder.encode(q, "UTF-8").replace("+","-")}/k0c217")
                found += parse(html, minYear, maxPrice, minScore)
            } catch (_: Exception) { }
        }

        val seen = prefs.getStringSet("seenUrls", emptySet())?.toMutableSet() ?: mutableSetOf()
        val unique = found.distinctBy { it.url }.filterNot { it.url in seen }
            .sortedByDescending { it.score }.take(10)
        if (token.isNotBlank() && chatId.isNotBlank()) {
            for (bike in unique) {
                if (sendTelegram(token, chatId, bike)) seen.add(bike.url)
            }
        }
        prefs.edit().putStringSet("seenUrls", seen.toList().takeLast(300).toSet()).apply()
        return Result.success()
    }

    private fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) AppleWebKit/537.36 Chrome/131 Safari/537.36")
        c.connectTimeout = 12000
        c.readTimeout = 12000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun parse(html: String, minYear: Int, maxPrice: Int, minScore: Int): List<Bike> {
        val out = mutableListOf<Bike>()
        val re = Pattern.compile(
            """href="([^"]*\/s-anzeige\/[^"]+)"[^>]*>(.*?)</a>""",
            Pattern.CASE_INSENSITIVE or Pattern.DOTALL
        )
        val m = re.matcher(html)
        while (m.find()) {
            val url = "https://www.kleinanzeigen.de" + m.group(1)
            val title = strip(m.group(2))
            val blockStart = max(0, m.start() - 1500)
            val blockEnd = min(html.length, m.end() + 1500)
            val block = strip(html.substring(blockStart, blockEnd))
            val price = extractPrice(block) ?: continue
            val year = Regex("""\b(20(?:1[0-9]|2[0-9]))\b""").find(block)?.groupValues?.get(1)?.toIntOrNull()
            if (minYear > 0 && year != null && year < minYear) continue
            if (price > maxPrice) continue
            val score = score("$title $block", price, year)
            if (score >= minScore) out += Bike(title, url, price, score)
        }
        return out
    }

    private fun score(text0: String, price: Int, year: Int?): Int {
        val t = text0.lowercase(Locale.GERMAN)
        var s = 45
        if (year != null) s += min(15, max(0, year - 2019) * 2)
        if (listOf("xt", "xtr", "slx").any { Regex("""\b${Regex.escape(it)}\b""").containsMatchIn(t) }) s += 8
        if (listOf("pike", "fox 34", "fox 36", "lyrik").any { t.contains(it) }) s += 8
        if (listOf("carbon", "carbonrahmen").any { t.contains(it) }) s += 7
        if (listOf("dt swiss", "350", "481").any { t.contains(it) }) s += 4
        if (t.contains("full") || t.contains("fully")) s += 5
        if (t.contains("e-bike") || t.contains("ebike") || t.contains("e-mtb")) s += 3
        if (listOf("bosch", "ep8", "ep801").any { t.contains(it) }) s += 8
        if (listOf("nur rahmen","only frame","rahmenbruch","defekt","unfall","motorschaden","akkudefekt","bastler","schlacht","beschädigt").any { t.contains(it) }) s -= 50
        if (price < 600) s += 10
        else if (price < 900) s += 7
        else if (price < 1200) s += 4
        return s.coerceIn(0, 100)
    }

    private fun extractPrice(s: String): Int? {
        val m = Regex("""(\d{2,5})\s*€""").find(s) ?: return null
        return m.groupValues[1].toIntOrNull()
    }

    private fun strip(s: String): String =
        s.replace(Regex("<[^>]+>"), " ").replace("&quot;","\"").replace("&amp;","&").replace(Regex("\\s+"), " ").trim()

    private fun sendTelegram(token: String, chatId: String, b: Bike): Boolean {
        val msg = "🚲 BIKE RADAR\n${b.title}\n💶 ${b.price} €\n⭐ ${b.score}/100\n${b.url}"
        val u = "https://api.telegram.org/bot${token}/sendMessage?chat_id=" +
                URLEncoder.encode(chatId, "UTF-8") + "&text=" +
                URLEncoder.encode(msg, "UTF-8")
        return try { org.json.JSONObject(fetch(u)).optBoolean("ok", false) } catch (_: Exception) { false }
    }
}
