package com.bikeradar.app

import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("bike_radar", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                BikeRadarScreen(
                    initialMaxPrice = prefs.getInt("maxPrice", 1500),
                    initialMinYear = prefs.getInt("minYear", 0),
                    initialMinScore = prefs.getInt("minScore", 60),
                    initialInterval = prefs.getInt("interval", 15),
                    initialToken = prefs.getString("token", "") ?: "",
                    initialChatId = prefs.getString("chatId", "") ?: "",
                    onSave = { maxPrice, minYear, minScore, interval, token, chatId ->
                        prefs.edit()
                            .putInt("maxPrice", maxPrice)
                            .putInt("minYear", minYear)
                            .putInt("minScore", minScore)
                            .putInt("interval", interval)
                            .putString("token", token)
                            .putString("chatId", chatId)
                            .apply()
                        scheduleWorker(this, interval)
                    },
                    onRunNow = { runNow(this) }
                )
            }
        }
    }
}

@Composable
fun BikeRadarScreen(
    initialMaxPrice: Int,
    initialMinYear: Int,
    initialMinScore: Int,
    initialInterval: Int,
    initialToken: String,
    initialChatId: String,
    onSave: (Int, Int, Int, Int, String, String) -> Unit,
    onRunNow: () -> Unit
) {
    var maxPrice by remember { mutableStateOf(initialMaxPrice.toString()) }
    var minYear by remember { mutableStateOf(if (initialMinYear == 0) "" else initialMinYear.toString()) }
    var minScore by remember { mutableStateOf(initialMinScore.toString()) }
    var interval by remember { mutableStateOf(initialInterval.toString()) }
    var token by remember { mutableStateOf(initialToken) }
    var chatId by remember { mutableStateOf(initialChatId) }
    val context = androidx.compose.ui.platform.LocalContext.current
    var running by remember { mutableStateOf(prefsRunning(context)) }
    var message by remember { mutableStateOf("Настрой фильтры и нажми «Проверить сейчас»") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("🚲 Bike Radar", style = MaterialTheme.typography.headlineMedium)
            Text("Поиск выгодных б/у MTB", style = MaterialTheme.typography.bodyMedium)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    onSave(
                        maxPrice.toIntOrNull() ?: 1500,
                        minYear.toIntOrNull() ?: 0,
                        minScore.toIntOrNull() ?: 60,
                        interval.toIntOrNull() ?: 15,
                        token, chatId
                    )
                    running = true
                    setRunning(context, true)
                    message = "Радар запущен: проверка будет выполняться по расписанию"
                }) { Text("▶ Запустить") }
                OutlinedButton(onClick = {
                    WorkManager.getInstance(context)
                        .cancelUniqueWork("bike_radar")
                    running = false
                    setRunning(context, false)
                    message = "Автоматическая проверка остановлена"
                }) { Text("■ Стоп") }
            }
        }
        item { Text("Статус: " + if (running) "запущен" else "остановлен") }
        item { OutlinedTextField(maxPrice, { maxPrice = it.filter(Char::isDigit) }, label={Text("Макс. цена (€)")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(minYear, { minYear = it.filter(Char::isDigit) }, label={Text("Минимальный год (необязательно)")}, supportingText={Text("Оставь пустым, чтобы смотреть все годы")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(minScore, { minScore = it.filter(Char::isDigit) }, label={Text("Минимальный score")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(interval, { interval = it.filter(Char::isDigit) }, label={Text("Интервал (мин.)")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(token, { token = it }, label={Text("Telegram Bot Token")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(chatId, { chatId = it }, label={Text("Telegram Chat ID")}, modifier=Modifier.fillMaxWidth()) }
        item {
            Button(onClick = {
                onSave(
                    maxPrice.toIntOrNull() ?: 1500,
                    minYear.toIntOrNull() ?: 0,
                    minScore.toIntOrNull() ?: 60,
                    interval.toIntOrNull() ?: 15,
                    token, chatId
                )
                onRunNow()
                message = "Проверка запущена. Результаты придут в Telegram"
            }, modifier=Modifier.fillMaxWidth()) {
                Text("🔎 Проверить сейчас")
            }
        }
        item { Text(message, style = MaterialTheme.typography.bodyMedium) }
        item {
            Text(
                "По умолчанию: до €1500, любой год, score 60+. Сейчас подключён первый источник — Германия. " +
                "Токен хранится только на телефоне. Старый токен, который уже был показан в чате, использовать нельзя — его нужно заменить.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun prefsRunning(context: Context): Boolean =
    context.getSharedPreferences("bike_radar", Context.MODE_PRIVATE).getBoolean("running", false)

private fun setRunning(context: Context, value: Boolean) {
    context.getSharedPreferences("bike_radar", Context.MODE_PRIVATE)
        .edit().putBoolean("running", value).apply()
}

fun scheduleWorker(context: Context, intervalMinutes: Int) {
    val request = PeriodicWorkRequestBuilder<BikeRadarWorker>(
        maxOf(15, intervalMinutes).toLong(), TimeUnit.MINUTES
    ).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "bike_radar", ExistingPeriodicWorkPolicy.UPDATE, request
    )
}

fun runNow(context: Context) {
    val request = OneTimeWorkRequestBuilder<BikeRadarWorker>().build()
    WorkManager.getInstance(context).enqueue(request)
}
