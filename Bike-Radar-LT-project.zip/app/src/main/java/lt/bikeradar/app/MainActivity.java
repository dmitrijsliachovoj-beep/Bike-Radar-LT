package lt.bikeradar.app;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.net.Uri; import android.view.*; import android.widget.*;
import java.io.*; import java.net.*; import java.util.*; import java.util.regex.*;

public class MainActivity extends Activity {
 LinearLayout results; EditText query,year,price; TextView status;
 int BG=Color.rgb(11,13,16), PANEL=Color.rgb(21,25,31), TXT=Color.rgb(244,246,248), MUT=Color.rgb(143,153,167), ACC=Color.rgb(168,255,62);
 public void onCreate(Bundle b){super.onCreate(b); ScrollView sv=new ScrollView(this); LinearLayout r=col(); r.setPadding(d(14),d(18),d(14),d(40)); sv.addView(r);
  TextView h=t("🚲 Bike Radar",28,TXT);h.setTypeface(null,1);r.addView(h);r.addView(t("🇱🇹 LITHUANIA FIRST · 0.5",12,ACC));
  r.addView(t("Пустое поле = без ограничения. Skelbiu — главный рынок.",13,MUT));
  query=in("Что ищем? Пусто = все велосипеды"); year=in("Год от · пусто = любой"); price=in("Цена до € · пусто = любая");
  r.addView(query);r.addView(year);r.addView(price);
  Button go=new Button(this);go.setText("🔎 ИСКАТЬ В ЛИТВЕ");go.setBackgroundColor(ACC);go.setTextColor(Color.BLACK);r.addView(go,new LinearLayout.LayoutParams(-1,d(54)));
  status=t("Готов к поиску",12,MUT);r.addView(status);results=col();r.addView(results);go.setOnClickListener(v->search());setContentView(sv);
 }
 void search(){results.removeAllViews();status.setText("Ищу Skelbiu LT…");String q=query.getText().toString().trim(), yf=year.getText().toString().trim(), pm=price.getText().toString().trim();
  new Thread(()->{ArrayList<Item>x=new ArrayList<>();String err=null;try{x=fetch(q,yf,pm);}catch(Exception e){err=e.getClass().getSimpleName()+": "+e.getMessage();} final ArrayList<Item> z=x; final String er=err;runOnUiThread(()->render(z,er));}).start();
 }
 ArrayList<Item> fetch(String q,String yf,String pm)throws Exception{
  String term=q.isEmpty()?"dviratis":q;String u="https://www.skelbiu.lt/paieska/"+URLEncoder.encode(term,"UTF-8").replace("+","%20")+"/";
  HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(18000);
  c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36");c.setRequestProperty("Accept-Language","lt-LT,lt;q=0.9,en;q=0.7");
  String h=read(c.getInputStream());ArrayList<Item>o=new ArrayList<>();HashSet<String>s=new HashSet<>();
  Matcher m=Pattern.compile("<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(h);
  while(m.find()&&o.size()<150){String href=dec(m.group(1)), title=clean(m.group(2));if(title.length()<8)continue;
   String url=href.startsWith("http")?href:"https://www.skelbiu.lt"+(href.startsWith("/")?"":"/")+href;if(!s.add(url))continue;
   String lo=title.toLowerCase(Locale.ROOT);if(!(lo.contains("dvir")||lo.contains("mtb")||lo.contains("bike")||lo.contains("cube")||lo.contains("trek")||lo.contains("giant")||lo.contains("canyon")||lo.contains("merida")||lo.contains("scott")||lo.contains("specialized")||lo.contains("polygon")))continue;
   Integer y=yr(title);Double p=pr(title);if(!yf.isEmpty()&&y!=null&&y<Integer.parseInt(yf))continue;if(!pm.isEmpty()&&p!=null&&p>Double.parseDouble(pm))continue;
   boolean w=any(lo,new String[]{"vaiki","kids","dalimis","detal","defekt","suged","remont","rėmas","frame only"});
   int sc=50+(w?-25:0)+(y!=null?3:0);if(lo.contains("xt"))sc+=7;if(lo.contains("xtr"))sc+=9;if(lo.contains("pike"))sc+=8;if(lo.contains("fox 36"))sc+=9;if(lo.contains("bosch"))sc+=6;
   o.add(new Item(title,url,p,y,Math.max(1,Math.min(99,sc)),w));
  }return o;
 }
 void render(ArrayList<Item>x,String err){status.setText(err!=null?"Ошибка источника: "+err:"🇱🇹 Найдено: "+x.size());Collections.sort(x,(a,b)->b.score-a.score);
  if(x.isEmpty())results.addView(t("Нет извлечённых объявлений. Если Skelbiu изменит защиту/разметку, коннектор потребуется обновить.",13,MUT));
  for(Item a:x){LinearLayout c=col();c.setPadding(d(12),d(12),d(12),d(12));c.setBackgroundColor(PANEL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,d(8),0,0);
   c.addView(t("🇱🇹 Skelbiu · "+(a.p==null?"€?":"€"+Math.round(a.p))+" · Score "+a.score,12,a.warn?Color.rgb(255,190,80):ACC));
   TextView tt=t(a.title,16,TXT);tt.setTypeface(null,1);c.addView(tt);c.addView(t((a.y==null?"год ?":""+a.y)+(a.warn?" · ⚠️ проверить":""),11,MUT));
   Button b=new Button(this);b.setText("ОТКРЫТЬ ОБЪЯВЛЕНИЕ →");b.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(a.url))));c.addView(b);results.addView(c,lp);}
 }
 EditText in(String h){EditText e=new EditText(this);e.setHint(h);e.setHintTextColor(MUT);e.setTextColor(TXT);e.setSingleLine();return e;}
 LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setBackgroundColor(BG);return l;} TextView t(String s,int z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setPadding(0,d(5),0,d(5));return v;}int d(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
 String read(InputStream i)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(i));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l).append('\n');return b.toString();}
 String clean(String s){return dec(s.replaceAll("<[^>]+>"," ").replaceAll("\\s+"," ")).trim();}String dec(String s){return s.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'");}
 boolean any(String s,String[]a){for(String x:a)if(s.contains(x))return true;return false;}Integer yr(String s){Matcher m=Pattern.compile("\\b(20\\d{2})\\b").matcher(s);Integer y=null;while(m.find()){int z=Integer.parseInt(m.group(1));if(z>=2000&&z<=2030)y=z;}return y;}
 Double pr(String s){Matcher m=Pattern.compile("(\\d{2,5}(?:[.,]\\d{1,2})?)\\s*(?:€|EUR)",Pattern.CASE_INSENSITIVE).matcher(s);if(m.find())try{return Double.parseDouble(m.group(1).replace(',','.'));}catch(Exception e){}return null;}
 static class Item{String title,url;Double p;Integer y;int score;boolean warn;Item(String t,String u,Double p,Integer y,int s,boolean w){title=t;url=u;this.p=p;this.y=y;score=s;warn=w;}}
}