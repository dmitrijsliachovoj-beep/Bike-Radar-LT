# Bike Radar LT 0.5
Native Android prototype: no Termux and no localhost website.

- Lithuania-first.
- Skelbiu LT is the first live connector.
- Empty year/price/search fields do not impose mandatory limits.
- Suspicious/parts/kids/defect terms are flagged instead of silently deleting listings.
- Original listing opens with one button.
- GitHub Actions workflow is included to build an installable APK.

Europe is intentionally a secondary connector layer; additional marketplaces can be added without changing the Lithuanian core.
