# Bike Radar LT

Android starter for the Bike Radar project.

## Build
GitHub Actions → Build Bike Radar APK → Run workflow.

The resulting artifact is named `Bike-Radar-LT-APK`.
